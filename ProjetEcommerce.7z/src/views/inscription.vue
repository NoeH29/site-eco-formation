<template>
  <div id="inscription">
    <form>
      <p id="head">Inscription</p>
      <input type="text" id="nom" name="nom" v-model="nom" placeholder="nom" />
      <input
        type="text"
        id="prenom"
        name="prenom"
        v-model="prenom"
        placeholder="prenom"
      />
      <input
        type="text"
        id="mail"
        name="mail"
        v-model="mail"
        placeholder="email@exemple.com"
      />
      <input
        type="password"
        id="password"
        name="password"
        v-model="password"
        placeholder="mot de passe"
      />
      <input
        type="password"
        id="confPassword"
        name="confPassword"
        v-model="confPassword"
        placeholder="confirmation de mot de passe"
      />
      <input
        type="text"
        id="telephone"
        name="telephone"
        v-model="telephone"
        placeholder="téléphone"
      />
      <button id="btn" type="submit" @click="inscription">S'inscrire</button>
      <p id="foot">Déja inscrit ?<a href="/connexion">Se connecter</a></p>
    </form>
  </div>
</template>
<script>
export default {
  data: function () {
    return {
      nom: "",
      prenom: "",
      mail: "",
      password: "",
      confPassword: "",
      telephone: "",
    };
  },
  methods: {
    inscription: function (e) {
      e.preventDefault();
      let info = {
        email: this.email,
        password: this.password,
      };
      this.$store.dispatch("inscription", info);
    },
  },
};
</script>

<style scoped>
form {
  margin: 100px;
  padding: 30px;
  width: 50%;
  display: inline-flex;
  flex-direction: column;
  gap: 30px;
  background-color: rgba(255, 255, 255, 0.472);
  border-radius: 5px;
  align-items: center;
  color: white;

 
  opacity: 0.75;
}

input {
  height: 25px;
  width: 75%;
  background-color: rgba(255, 255, 255, 0.637);
  border-radius: 5px;
  box-shadow: 10px 10px 5px grey;
  font-weight: bold;
 
}
input::-webkit-input-placeholder {
  color: black;
}

button {
  height: 25px;
  width: 100px;
  background-color: #5f5439b9;
  border-radius: 5px;
  cursor: pointer;
  font-weight: bold;
}
button:hover {
  transform: translate(5px, 5px);
  background-color: #474130;
  box-shadow: 5px 5px 5px grey;
}
#head {
  font-size: 30px;
  font-weight: bold;
}
#foot {
  font-size: 20px;
  font-weight: bold;
}
</style>